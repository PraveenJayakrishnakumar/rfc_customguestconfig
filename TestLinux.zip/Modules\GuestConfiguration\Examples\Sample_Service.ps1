<#
    .SYNOPSIS
        Stops and then removes the service with the name Service1.
#>
Configuration Sample_Service
{
    [CmdletBinding()]
    param
    ()

    Import-DscResource -ModuleName 'GuestConfiguration'

    Node localhost
    {
        Service ServiceResource1
        {
            Name = 'Service1'
            Ensure = 'Absent'
        }
    }
}
